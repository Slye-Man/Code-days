while True:
    print('Welcome to Python Pizza Deliveries')

    size = input("What size pizza would you like? \nSmall, Medium or Large \n S, M, L ").lower()
    add_pepperoni = input("Would you like some pepperoni? Y or N \n").lower()
    extra_cheese = input('Would like some extra cheese? Y or N \n').lower()

    if size == 'Small' or size == 'S':
        cost = 20
        print('Small Pizza: R{}'.format(cost))

        if add_pepperoni == 'y':
            cost += 5
            print('That would be R{}'.format(cost))

        else:
            print(cost)

        if extra_cheese == 'y':
            cost += 10
            print('That would be R{}'.format(cost))

        else:
            print('Total cost is R{}'.format(cost))
    elif size == 'Medium' or size == 'M':
        cost = 50
        print(f'Medium Pizza: R{cost}')

        if add_pepperoni == 'y':
            cost += 5
            print('That would be R{}'.format(cost))

        else:
            print(cost)

        if extra_cheese == 'y':
            cost += 10
            print('That would be R{}'.format(cost))

        else:
            print('Total cost is R{}'.format(cost))

    elif size == 'large' or size == 'l':
        cost = 100
        print('Large Pizza: R{}'.format(cost))

        if add_pepperoni == 'y':
            cost +=5
            print('That would be R{}'.format(cost))
        else:
            print('Total cost is R{}'.format(cost))

        else:
            print('Total cost is R{}'.format(cost))
    else:
        print('You have picked an invalid option')
while True:
    year = int(input('Please enter year you want to check: '))

    if year % 4 == 0:
        print(f'{year} is a leap year')
    else:
        print('{} is NOT a leap year'.format(year))

print('''
 _                                     _     _                 _
| |                                   (_)   | |               | |
| |_ _ __ ___  __ _ ___ _   _ _ __ ___ _ ___| | __ _ _ __   __| |
| __| '__/ _ \/ _` / __| | | | '__/ _ \ / __| |/ _` | '_ \ / _` |
| |_| | |  __/ (_| \__ \ |_| | | |  __/ \__ \ | (_| | | | | (_| |
 \__|_|  \___|\__,_|___/\__,_|_|  \___|_|___/_|\__,_|_| |_|\__,_|''')
print('''
*******************************************************************************
          |                   |                  |                     |
 _________|________________.=""_;=.______________|_____________________|_______
|                   |  ,-"_,=""     `"=.|                  |
|___________________|__"=._o`"-._        `"=.______________|___________________
          |                `"=._o`"=._      _`"=._                     |
 _________|_____________________:=._o "=._."_.-="'"=.__________________|_______
|                   |    __.--" , ; `"=._o." ,-"""-._ ".   |
|___________________|_._"  ,. .` ` `` ,  `"-._"-._   ". '__|___________________
          |           |o`"=._` , "` `; .". ,  "-._"-._; ;              |
 _________|___________| ;`-.o`"=._; ." ` '`."\` . "-._ /_______________|_______
|                   | |o;    `"-.o`"=._``  '` " ,__.--o;   |
|___________________|_| ;     (#) `-.o `"=.`_.--"_o.-; ;___|___________________
____/______/______/___|o;._    "      `".o|o_.--"    ;o;____/______/______/____
/______/______/______/_"=._o--._        ; | ;        ; ;/______/______/______/_
____/______/______/______/__"=._o--._   ;o|o;     _._;o;____/______/______/____
/______/______/______/______/____"=._o._; | ;_.--"o.--"_/______/______/______/_
____/______/______/______/______/_____"=.o|o_.--""___/______/______/______/____
/______/______/______/______/______/______/______/______/______/______/[TomekK]
*******************************************************************************''')

while True:
    print("Welcome to Treasure Island \nYour mission is to find the treasure")

    print('You are walking through the woods. Up ahead you notice a sign. You either go left or right.')

    option1 = input('Left or Right: ').lower()
    if option1 == 'left':
        print('You arrive at the shore of a raging river. Do you wait for a boat or do you swim? :')

        option2 = input('Swim or Wait: ').lower()
        if option2 == 'wait':
            print('After waiting for five hours the boat has finally arrived. The boat drops you off and you carry on')
            print("You come across a building with three doors in different colors. Red, Blue or Green.")
            print('The treasure is behind one of those doors. Pick wisely')
            option3 = input('Red, Blue or Green ').lower()
            
            if option3 == 'red':
                print('You opened the red door and walked through it. The door closes behind you. You walked in a room of fire and you get torched to death.')
                print('Game Over!')
                print('')
            elif option3 == 'green':
                print('You walk through the green door. The room quickly fills up with water. You drown to death')
                print('Game Over!')
                print('')
            elif option3 == 'blue':
                print('You walk through the blue door. The door closes behind you. Fortunately the fourth option is found in the colors of the rainbow')
                print('All the air in the room dispenses and you are gasping for air. You suffocate to death')
                print('Game Over!')
                print('')
            elif option3 == 'orange':
                print('You have found the secret door. Your treasure awaits you young traveler. \nYou win!')
                print('')
            else:
                print('You have choosen a door color that does not exist. Game Over!')
                print('')

        else:
            print('You swam across the river but before reaching the shore you get torn to pieces by visicious crocediles')
            print('Game Over!')
            print('')
        
    else:
        print('You fell through a trapdoor where your demise is met with poisioned spikes. \nGame over!')
        print('')

        


#Create a program that would greet the user
print('Welcome to the love calculator')
#Prompt user to input their names and the crush's names.
#Change the names to lower case
name1 = input('Please enter your name: ').lower()
name2 = input("Please enter your crush's name: ").lower()

combine_name = name1 + name2
print(combine_name)
#Using TRUE LOVE count the number of character
t = combine_name.count('t')
r = combine_name.count('r')
u = combine_name.count('u')
e = combine_name.count('e')

true = t + r + u + e

l = combine_name.count('l')
o = combine_name.count('o')
v = combine_name.count('v')
e = combine_name.count('e')

love = l + o + v + e
#Convert the int into strings
love_score = str(true) + str(love)

print(love_score)

if (int(love_score) < 10) or (int(love_score) > 90):
    print('Your love score is {}, you go together like coke and mentos'
          .format(love_score))
elif (int(love_score) >= 40) or (int(love_score) <= 50):
    print('Your love score is {}, you are alright for each other'
          .format(love_score))
else:
    print('Your love score is {}'.format(love_score))

#Prompt user for their weight and height
height = float(input('Please enter your height in m: '))
weight = float(input('Please enter your weight in kg: '))

#Round answer to one decimal place
bmi = round(weight/(height **2),1)

#bmi = float(input('Please input your bmi: '))
#Create a condition for different BMI. Use the BMI website for info
if bmi <= 18.5:
    print('Your bmi is {}. You are underweight'.format(bmi))
elif bmi > 18.5 and bmi <= 25:
    print('Your bmi is {}. You are normal weight'.format(bmi))
elif bmi > 25 and bmi <=30:
    print('Your bmi is {}. You are overweight'.format(bmi))
elif bmi > 30 and bmi <= 35:
    print('Your bmi is {}. You are obese'.format(bmi))
else:
    print('Your bmi is {}. You are clinically obese'.format(bmi))

print(bmi)

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day_2_BMI_LIFE_EXPECTENACY_CALC
{
    class Program
    {
        enum MyEnum
        {
            bmi_CAL =1,
            dateofdeath=2,
            tip_CALCI=3,
            exit=0
        }
     
        static void Main(string[] args)
        {
         
          

                Console.WriteLine("Please select a feature for BMI calculator or Expected death date");
                Console.WriteLine("Enter 1 for BMI CAL");
                Console.WriteLine("Enter 2 for DEATH_DAY CAL");
                Console.WriteLine("Enter 3 for Tip calculator");

                int user_input = int.Parse(Console.ReadLine());
                MyEnum feature_select = (MyEnum)user_input;

                switch (feature_select)
                {
                    case MyEnum.bmi_CAL:
                        BMI_calculator();
                        break;
                    case MyEnum.dateofdeath:
                        Dateofdeath();
                        break;
                    case MyEnum.tip_CALCI:

                        tip_calculator();
                        break;
                    case MyEnum.exit:
                        Console.WriteLine("input 0 to exit");
                        Environment.Exit(0);
                        break;
                    default:
                        break;
                }
            

  


            Console.ReadKey();

        }

        private static void tip_calculator()
        {
            Console.WriteLine("Hi welcome to the stores automated tip calculator:");
            Console.WriteLine("Please input what percentage of the tip you'd like to give /t note you can give anywhere from 5 to 15 percent.");
            int percentage = int.Parse(Console.ReadLine());
            Console.WriteLine("How much did the meanl cost");
            double cost_of_meal = double.Parse(Console.ReadLine());
            Console.WriteLine("Amount of people in the  group:");
            int people_in_group = int.Parse(Console.ReadLine());
            Console.WriteLine("Sub-total:{0}",cost_of_meal);
            double total = percentage * cost_of_meal / 100+cost_of_meal;
            Console.WriteLine("Total:{0}",total);
            Console.WriteLine("Amount each member in the group needs to pay:{0}",total/people_in_group);
            
        }

        private static void BMI_calculator()
        {
            Console.WriteLine("Please enter you height in cm");
            int height = int.Parse(Console.ReadLine());
            Console.WriteLine("Please enter you WEIGHT in kG");
            double weight =double.Parse( Console.ReadLine());

            Console.WriteLine("YOUR BMI IS:"); 

            double BMI= height*height / weight;
            Console.WriteLine(BMI);
            
        
        }

        private static void Dateofdeath()
        {
            Console.WriteLine("Insert year of age");
            int age = int.Parse(Console.ReadLine());
            Console.WriteLine("Insert year of birth");
            int year = int.Parse(Console.ReadLine());
            int diff = year + age;
          
           

       DateTime dateofbirth = new DateTime(diff, 01, 01, 0, 0, 0);
            DateTime deathdare = new DateTime(year+90, 01, 01, 0, 0, 0);

            TimeSpan Diff_dates = deathdare.Subtract(dateofbirth);

            Console.WriteLine("Difference in years = " + Diff_dates.Days / 365.5);
            Console.WriteLine("Exact timespan in Months = " + Diff_dates.Days / 30);
            Console.WriteLine("Exact timespan in days = " + Diff_dates.Days);


        }
    }
}

#Create a program that tells the users their BMI

greet = ("Good day! Welcome to the BMI Caluculator")
print(greet)

#Prompt user for their height and weight
height = input("Please input your height in m: \n")
weight = input("Please input your weight in kg: \n")

#Convert user input into int and float
BMI = int(weight)/float(height)**2
bmiInt = int(BMI)
print('Your bmi is {}'.format(bmiInt))

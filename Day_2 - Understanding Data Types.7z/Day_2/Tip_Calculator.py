#Create a Tip Calculator and greet whoever wants to use it

greet = ('Welcome to the tip calculator!')
print(greet)
print('')
#Ask how much the bill is

bill = float(input('What is your total bill? \nR'))

#Prompt how much tip they would like to give

tip = int(input('How much tip would you like to give? \n10% \n12% \n15% \nPlease input numerical value only \n'))

#Prompt how many people are splitting the bill

user = int(input('How many people would like to split the bill? \n'))

#Calculate the final bill amount along with the tip amount and how much each person should pay

tipPercentage = tip/100
tipAmount = bill * tipPercentage
totalAmount = round(bill + tipAmount,2)
billPp = totalAmount/user
finalAmount = round(billPp,2)
print("Your total bill, including tip, is R{}".format(totalAmount))
print('Each person should pay: R{}'.format(finalAmount))

# Create a progam that tells the user their age in weeks and months
#age = int(input("What is your current age \n"))

#years = age
#days = age * 365
#week_s = age * 52
#month_s = age * 12

#print('You are {} years young, {} weeks and {} months '.format(years,week_s,month_s))

# Given that an average lifespan is 90, create a program that shows the user much time left.
lifespan = 90
age = int(input('Age please: \n'))

years_remaining = lifespan - age
days_remaining = (lifespan * 365) - (age * 365)
week_s_remaining = (lifespan * 52) - (age * 52)
month_s_remaining = (lifespan * 12 ) - (age * 12)

print('You approxiamtely have {} years left, {} months, {} weeks and {} days '
      .format(years_remaining, month_s_remaining,week_s_remaining,
              days_remaining))
print('Make your time count. Life is short and extremely unpredictable')

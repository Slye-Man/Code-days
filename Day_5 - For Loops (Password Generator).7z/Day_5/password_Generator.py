#Password Generator
import random
letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
symbols = ['!', '#', '$', '%', '&', '(', ')', '*', '+','@']

print("Welcome to the PyPassword Generator!")

num_of_letters= int(input("How many letters would you like in your password?\n")) 
num_of_symbols = int(input("How many symbols would you like?\n"))
num_of_numbers = int(input("How many numbers would you like?\n"))

#Easy level
#Getting letters
#password = ''   #Initiliazing password. Empty string

#Assuming that num of letters is = 4
##for char in range(1, num_of_letters + 1):
##    #range will go from 1 - 4
##    random_char = random.choice(letters)    #we got 'letters' from declaration
##    password += random_char     #placing a value in the empty string 'password'
##    #password = password + random_char. Mehtod is similar as above
##    print(random_char)  #prints random characters
##    print(password)     #prints and concatenates random characters

#A simpler version of the code above
    
##for char in range(1, num_of_letters + 1):
##    password += random.choice(letters)

#Getting numbers
#password = ''

#Assuming that num of symbols is 2
##for char in range (1, num_of_symbols + 1):
##    #range will go from 1-2
##    random_sym = random.choice(symbols)
##    password += random_sym
##    print(random_sym)
##    print(password)

#Simpler version of the above code,

##for char in range(1, num_of_symbols + 1):
##    password += random.choice(symbols)

#Getting numbers
#password = ''

#Assuming that num of numbers is 2
##for char in range (1, num_of_numbers + 1):
##    #range will go from 1-2
##    random_num = random.choice(numbers)
##    password += random_sym
##    print(random_num)
##    print(password)

#Simpler verion of the above code

##for char in range(1, num_of_numbers + 1):
##    password += random.choice(numbers)

#print(password)


#------------------------------------------------
#Hard Level
password_list = []
for char in range(1, num_of_letters + 1):
    password_list += random.choice(letters)

for char in range(1, num_of_symbols + 1):
    password_list += random.choice(symbols)

for char in range(1, num_of_numbers + 1):
    password_list += random.choice(numbers)

print(password_list)
random.shuffle(password_list) #Shuffles the existing list withput the need of creating one
print(password_list)

password_list = ''
for char in password_list:
	password += char

print('Your password is {}'.format(password_list))










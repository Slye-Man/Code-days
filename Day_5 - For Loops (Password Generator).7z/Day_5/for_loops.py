#For loops

#fruits = ['Apple', 'Banana', 'Carrot', 'Peach', 'Mango']
#for fruit in fruits:
#    print(fruit)

#Create a different flavor pie by iterating through the list without changing it

#for fruit in fruits:
#    print(fruit + " pie")



#You can also do it this way 

fruits = ['Apple', 'Banana', 'Carrot', 'Peach', 'Mango']
for fruit in fruits:
    print(fruit)
    print(fruit + ' pie')






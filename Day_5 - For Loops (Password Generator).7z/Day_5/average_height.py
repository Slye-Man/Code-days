#Create a list of basketball players heights in cm and calculate the average height

bb_playerHeights = input('Please input basketball player heights ').split()
for height in range(0, len(bb_playerHeights)):
    bb_playerHeights[height] = int(bb_playerHeights[height])

print(bb_playerHeights)


total_height = 0
#Calculates the total height within the given list
#Subtitutes the sum function
for height in bb_playerHeights:
    total_height += height
print(total_height)

number_of_players = 0
#Checks how many players are in the list
#Subtitues the len function
for players in bb_playerHeights:
    number_of_players += 1 #The plus one is to shift the index that it starts from one instead of start from zero
print(number_of_players)

#Calculating the average height
average_height = round(total_height / number_of_players)
print(average_height)

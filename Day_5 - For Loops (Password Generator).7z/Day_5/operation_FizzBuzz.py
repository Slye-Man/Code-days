#Create a program that iterates through a list of numbers
#When the number is divisible by 3 it should be replaced with the word fizz
#When the number is divisible by 5 it should be replaced with the word buzz
#When the number is divisible by 3 and 5 it should be replaced with the word fizzBuzz

for number in range(1,101):
    if number % 3 == 0 and number % 5 == 0:
        print('Fizz Buzz')
    elif number % 5 == 0:
        print('Buzz')
    elif number % 3 == 0:
        print('Fizz')
    else:
        print(number)












#For Loop with Range
#Looping within the given range in multiples of one
for number in range(1, 11):
    print(number)
print('')

#Looping within the given range in multiples of four

for num in range(1, 40, 4):
    print(num)
print('')
#Adding numbers from 1 to 100

total = 0
for number in range(1,101):
    total += number
print(total)
print('')

#Answer should give you 5050

#Write a program that adds only the even numbers in the given range

addEven = 0
for evenNum in range(2,101,2):
    if evenNum % 2 == 0:
        addEven += evenNum
print(addEven)

#Different method for above query

even = 0
for num in range(2,101,2):
    even += num
print(even)















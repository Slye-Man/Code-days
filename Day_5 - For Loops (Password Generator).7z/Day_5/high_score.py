#Create a program that will display a list of game highscores

game_highscores = input("Please enter a list of high scores ").split()

for score in range(0, len(game_highscores)):
    game_highscores[score] = int(game_highscores[score])

print(game_highscores)


score = 0
for highscore in game_highscores:
  if highscore > score:     #checks if the first score is higher than zero. If it is it replaces the value of score with the highest score.
      score = highscore     #keeps iterating until score is equal to the highest score.
print('The highest score is {}'.format(score))

while True:
    greet = ('Welcome to the roller coaster!')
    print(greet)

    height = int(input('Please enter your height in cm: '))
    bill = 0

    if height > 120:
        print('You can ride the rollercoaster!')
        age = int(input('Please input your age: '))

        if age <= 12:
            bill = 30
            print('The cost is R{}'.format(bill))
        elif age > 18:
            bill = 140
            print('The cost is R{}'.format(bill))
            #Add another statement for people who are experiencing a midlife crisses.
        elif age >= 45 and age <= 55:
            print('Everything is going to be alright. Have a free ride on us')
        else:
            bill = 70
            print('The cost is R{}'.format(bill))

        want_photo = input('Would you like a photo taken? Y or N ')
        if want_photo == 'Y':
            bill +=3
            print('Your final bill is R{}'.format(bill))

        else:
            print(f'Your final bill is R{bill}')

    else:
        print('The reccommended hieght for this ride is 120cm and above')

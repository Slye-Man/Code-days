﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day1_App
{
    class Program
    {
        static void Main(string[] args)

        {
        
        
            Console.WriteLine("Welcome to band name generator!");

            Console.WriteLine("Please enter your Place of birth, please eneter a city/town ");
            string POB = Console.ReadLine();
            Console.WriteLine("Please enter your pet name:");
            string Pet_name = Console.ReadLine();

            string str = POB.Substring(0, 3);

            Console.WriteLine(str+Pet_name);



            Console.ReadKey();

        }
    }
}
